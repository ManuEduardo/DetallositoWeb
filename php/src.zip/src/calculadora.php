<?php 

include "operaciones.php";
$n1 = (integer) $_POST["numero1"]; 
$n2 = (integer) $_POST["numero2"]; 
$operacion = (integer) $_POST["operacion"];
switch ($operacion) {
    case 1:
        echo "La suma es: ".sumar($n1, $n2);
        break;
    case 2:
        echo "La resta es: ".restar($n1, $n2);
        break;
    case 3:
        echo "La multiplicación es: ".multiplicar($n1, $n2);
        break;
    case 4:
        echo "La divición es: ".dividir($n1, $n2);
        break;
    case 5:
        echo "La potenciación es: ".potenciar($n1, $n2);
        break;
    default:
        echo "Opción Invalida";
        break;
}
?>

