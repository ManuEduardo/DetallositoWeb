<?php
function sumar($n1, $n2){
    $resultado = $n1 + $n2;
    return $resultado;
}

function restar($n1, $n2){
    $resultado = $n1 - $n2;
    return $resultado;
}

function multiplicar($n1, $n2){
    $resultado = $n1 * $n2;
    return $resultado;
}

function dividir($n1, $n2){
    if($n1 == 0 ){
        return "Primer numero no valido";
    }
    $resultado = $n1 / $n2;
    return $resultado;
}

function potenciar($n1, $n2){
    $resultado = pow($n1, $n2);
    return $resultado;
}

?>